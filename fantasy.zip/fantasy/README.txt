Fantasy
A free 3D model kit from Shuriken Studio
https://shuriken.studio/kits/fantasy

A free low-poly fantasy kit for Roblox Studio: 31 matching GLB models for an RPG, a dungeon crawler or a magic adventure map. Buildings like a leaning wizard tower, an elven treehouse and a floating sky island give the world its landmarks, with a boss arena for the final fight. Loot comes as a tiered sword set, a bow tier set and tiered magic staffs, alongside a potion set and an enchanted treasure chest. Props like an alchemist's table, a glowing rune waystone and mana crystal nodes fill the spaces between quests. A slime set and a club goblin give players their first enemies, and a dragon treasure hoard waits at the end. The tiered weapons give you a ready-made progression from starter gear to late-game loot. Weapons, props and buildings share one stylised low-poly look, so loot from this kit fits any of the library's other worlds.

31 models, as GLB (glTF 2.0) files:
  leaning-wizard-tower.glb       Leaning Wizard Tower  https://shuriken.studio/models/buildings/leaning-wizard-tower
  elven-treehouse.glb            Elven Treehouse  https://shuriken.studio/models/buildings/elven-treehouse
  floating-sky-island.glb        Floating Sky Island  https://shuriken.studio/models/scenery/floating-sky-island
  dragon-treasure-hoard.glb      Dragon Treasure Hoard  https://shuriken.studio/models/props/dragon-treasure-hoard
  fairy-mushroom-house.glb       Fairy Mushroom House  https://shuriken.studio/models/buildings/fairy-mushroom-house
  dragon-statue-fountain.glb     Dragon Statue Fountain  https://shuriken.studio/models/props/dragon-statue-fountain
  low-poly-boss-arena.glb        Low-Poly Boss Arena  https://shuriken.studio/models/kits/low-poly-boss-arena
  low-poly-slime-set.glb         Low-Poly Slime Set  https://shuriken.studio/models/characters/low-poly-slime-set
  bow-tier-set.glb               Bow Tier Set  https://shuriken.studio/models/weapons/bow-tier-set
  low-poly-shield-set.glb        Low-Poly Shield Set  https://shuriken.studio/models/weapons/low-poly-shield-set
  fantasy-stone-bridge.glb       Fantasy Stone Bridge  https://shuriken.studio/models/buildings/fantasy-stone-bridge
  low-poly-pirate-ship.glb       Low-Poly Pirate Ship  https://shuriken.studio/models/vehicles/low-poly-pirate-ship
  dungeon-iron-door.glb          Dungeon Iron Door  https://shuriken.studio/models/props/dungeon-iron-door
  low-poly-potion-set.glb        Low-Poly Potion Set  https://shuriken.studio/models/items/low-poly-potion-set
  dragon-egg-nest.glb            Dragon Egg Nest  https://shuriken.studio/models/props/dragon-egg-nest
  healing-fountain.glb           Healing Fountain  https://shuriken.studio/models/props/healing-fountain
  enchanted-treasure-chest.glb   Enchanted Treasure Chest  https://shuriken.studio/models/props/enchanted-treasure-chest
  alchemists-table.glb           Alchemists Table  https://shuriken.studio/models/props/alchemists-table
  tiered-magic-staffs.glb        Tiered Magic Staffs  https://shuriken.studio/models/weapons/tiered-magic-staffs
  spellbook-lectern.glb          Spellbook Lectern  https://shuriken.studio/models/props/spellbook-lectern
  royal-throne-dais.glb          Royal Throne Dais  https://shuriken.studio/models/furniture/royal-throne-dais
  club-goblin.glb                Club Goblin  https://shuriken.studio/models/characters/club-goblin
  combat-vfx-mesh-set.glb        Combat VFX Mesh Set  https://shuriken.studio/models/effects/combat-vfx-mesh-set
  knight-armor-stand.glb         Knight Armor Stand  https://shuriken.studio/models/props/knight-armor-stand
  fortune-tellers-table.glb      Fortune Tellers Table  https://shuriken.studio/models/props/fortune-tellers-table
  glowing-rune-waystone.glb      Glowing Rune Waystone  https://shuriken.studio/models/props/glowing-rune-waystone
  rune-stone-circle.glb          Rune Stone Circle  https://shuriken.studio/models/props/rune-stone-circle
  giant-fantasy-mushrooms.glb    Giant Fantasy Mushrooms  https://shuriken.studio/models/nature/giant-fantasy-mushrooms
  mana-crystal-nodes.glb         Mana Crystal Nodes  https://shuriken.studio/models/nature/mana-crystal-nodes
  magical-floating-lanterns.glb  Magical Floating Lanterns  https://shuriken.studio/models/props/magical-floating-lanterns
  tiered-sword-set.glb           Tiered Sword Set  https://shuriken.studio/models/weapons/tiered-sword-set

Using them
  Roblox Studio: Import 3D, choose a GLB, insert.
  Blender: File > Import > glTF 2.0.
  Unity, Godot, Unreal, three.js: import directly or through glTF.

Terms
  Free to use in any project, commercial games included: no account, no fee and no credit needed.
  Don't sell or share the model files themselves, alone or as a pack. They come as they are, with
  no warranty. LICENSE.txt has the short version; the full license is at https://shuriken.studio/legal/models
